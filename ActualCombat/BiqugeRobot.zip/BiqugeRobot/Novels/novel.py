# -*- encoding : utf-8 -*-
# @Author : Fenglchen

class Novels:
    # 当前笔趣阁全部小说书名以及url
    novels_name_url = []
    # 保存小说全部章节以及url
    novel_chapter_url = []
    # 保存当前下载小说名字
    schedule_book_name = []